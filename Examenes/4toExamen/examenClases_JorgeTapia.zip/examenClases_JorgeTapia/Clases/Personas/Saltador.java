package examenClases_JorgeTapia.Clases.Personas;

import examenClases_JorgeTapia.Clases.Paracaidas;

public abstract class Saltador extends Cliente
{
    //Atributos
    Cliente cliente;
    Paracaidas p1;
    Paracaidas p2;

    //Constructor
    public Saltador(String nombre, String apellidos, String tlf, int alturaSalto, boolean segVida, Cliente cliente,
            Paracaidas p1, Paracaidas p2) 
    {
        super(nombre, apellidos, tlf, alturaSalto, segVida);
        this.cliente = cliente;
        this.p1 = p1;
        this.p2 = p2;
    }

    //Metodos
    @Override
    public String informacion()
    {
        return getNombre() + getApellidos() + getAlturaSalto();
    }

    

    

    
}