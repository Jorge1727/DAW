package examenClases_JorgeTapia.Clases;

public class Avion 
{
    //Atributos
    private String matricula;
    private int potencia;
    private int capSaltadores;
    private int alturaMax;
    private boolean alquilado;

    //Constructor
    public Avion(String matricula, int potencia, int capSaltadores, int alturaMax, boolean alquilado) 
    {
        this.matricula = matricula;
        this.potencia = potencia;
        this.capSaltadores = capSaltadores;
        this.alturaMax = alturaMax;
        this.alquilado = alquilado;
    }

    

    
}
