package examenClases_JorgeTapia.Clases;

import examenClases_JorgeTapia.Clases.Personas.Instructor;

public class Paracaidas 
{
    //Atributos
    public enum Marca{MOLTEM, CAIDALIBRE, ALTUS};

    private static int id = 1;

    private int num_id;
    private int anioFab;
    private Marca tipoMarca;
    public Instructor instructor;

    //Constructor
    public Paracaidas(int anioFab, Marca tMarca, Instructor instructor) 
    {
        this.num_id = id;
        this.anioFab = anioFab;
        this.tipoMarca = tMarca;
        this.instructor = instructor;

        id++;
    }

    //

    
}
